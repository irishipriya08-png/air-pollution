export type EventType = 'thunderstorm' | 'cloudburst' | 'flash_flood';
export type Severity = 'watch' | 'warning' | 'critical';
export type AlertStatus = 'active' | 'expired' | 'acknowledged';

export interface MeteorologicalTriggers {
  iwv: number;
  cape: number;
  cin: number;
  ctt_drop: number;
  convergence: number;
  shear: number;
  slope?: number;
  elevation?: number;
}

export interface WeatherAlert {
  id: string;
  event_type: EventType;
  severity: Severity;
  location_name: string;
  lat: number;
  lng: number;
  probability: number;
  lead_time_hours: number;
  description: string;
  meteorological_triggers: MeteorologicalTriggers;
  status: AlertStatus;
  created_at: string;
  expires_at: string | null;
}

export interface SystemMetrics {
  id: string;
  model_version: string;
  inference_latency_ms: number;
  grid_cells_analyzed: number;
  active_alerts: number;
  coverage_area_km2: number;
  accuracy_pct: number;
  timestamp: string;
}

export interface AlertSubscription {
  id: string;
  contact_name: string;
  phone: string | null;
  email: string | null;
  district: string;
  state: string;
  alert_types: string[];
  created_at: string;
}

export interface GridCell {
  lat: number;
  lng: number;
  risk: number;
  iwv: number;
  cape: number;
  ctt: number;
}

export interface VariableReading {
  timestamp: string;
  iwv: number;
  cape: number;
  cin: number;
  ctt: number;
  convergence: number;
  shear: number;
  precipitation: number;
}

export type ViewKey = 'dashboard' | 'map' | 'analytics' | 'alerts' | 'xai' | 'subscriptions';
