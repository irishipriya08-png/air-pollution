import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { WeatherAlert, SystemMetrics, AlertSubscription } from '@/types';
import { generateRiskGrid, generateVariableHistory, generateForecastSeries } from '@/lib/predictionEngine';
import type { GridCell, VariableReading } from '@/types';

export function useAlerts() {
  const [alerts, setAlerts] = useState<WeatherAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error: e } = await supabase
      .from('weather_alerts')
      .select('*')
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (e) {
      setError(e.message);
    } else {
      setAlerts((data ?? []) as WeatherAlert[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const acknowledge = useCallback(async (id: string) => {
    const { error: e } = await supabase
      .from('weather_alerts')
      .update({ status: 'acknowledged' })
      .eq('id', id);
    if (e) {
      setError(e.message);
      return;
    }
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  }, []);

  const dismiss = useCallback(async (id: string) => {
    const { error: e } = await supabase
      .from('weather_alerts')
      .update({ status: 'expired' })
      .eq('id', id);
    if (e) {
      setError(e.message);
      return;
    }
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  }, []);

  return { alerts, loading, error, load, acknowledge, dismiss };
}

export function useMetrics() {
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from('system_metrics')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      setMetrics(data as SystemMetrics);
    } else {
      setMetrics({
        id: 'demo',
        model_version: 'NowCastNet-v2.1',
        inference_latency_ms: 340,
        grid_cells_analyzed: 128000,
        active_alerts: 5,
        coverage_area_km2: 3287000,
        accuracy_pct: 91.2,
        timestamp: new Date().toISOString(),
      });
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { metrics, loading, load };
}

export function useSubscriptions() {
  const [subs, setSubs] = useState<AlertSubscription[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from('alert_subscriptions')
      .select('*')
      .order('created_at', { ascending: false });
    setSubs((data ?? []) as AlertSubscription[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const add = useCallback(async (sub: Omit<AlertSubscription, 'id' | 'created_at'>) => {
    const { data } = await supabase
      .from('alert_subscriptions')
      .insert(sub)
      .select()
      .maybeSingle();
    if (data) {
      setSubs((prev) => [data as AlertSubscription, ...prev]);
    }
  }, []);

  const remove = useCallback(async (id: string) => {
    await supabase.from('alert_subscriptions').delete().eq('id', id);
    setSubs((prev) => prev.filter((s) => s.id !== id));
  }, []);

  return { subs, loading, load, add, remove };
}

export function useRiskGrid(selectedHour: number) {
  const [grid, setGrid] = useState<GridCell[]>([]);

  useEffect(() => {
    setGrid(generateRiskGrid(selectedHour));
  }, [selectedHour]);

  return grid;
}

export function useVariableHistory() {
  const [history, setHistory] = useState<VariableReading[]>([]);

  useEffect(() => {
    setHistory(generateVariableHistory(24));
  }, []);

  return history;
}

export function useForecastSeries() {
  const [series] = useState(() => generateForecastSeries(6));
  return series;
}
