import { useState, useMemo } from 'react';
import { RiskMap } from '@/components/RiskMap';
import { AtmosphericPanel } from '@/components/AtmosphericPanel';
import { ForecastTimeline } from '@/components/ForecastTimeline';
import { XAIPanel } from '@/components/XAIPanel';
import { useRiskGrid, useForecastSeries, useAlerts } from '@/hooks/useData';
import { generateTriggers, classifySeverity, EVENT_META, SEVERITY_META } from '@/lib/predictionEngine';
import type { GridCell, EventType } from '@/types';
import { MapPin, Crosshair } from 'lucide-react';

export function MapView() {
  const forecast = useForecastSeries();
  const { alerts } = useAlerts();
  const [selectedHour, setSelectedHour] = useState(0);
  const grid = useRiskGrid(selectedHour);
  const [selectedCell, setSelectedCell] = useState<GridCell | null>(null);

  const cellTriggers = useMemo(() => {
    if (!selectedCell) return null;
    const risk = selectedCell.risk;
    const type: EventType = risk > 0.7 ? 'cloudburst' : risk > 0.5 ? 'thunderstorm' : 'thunderstorm';
    return { type, triggers: generateTriggers(type, risk), severity: classifySeverity(risk) };
  }, [selectedCell]);

  return (
    <div className="p-6 space-y-5">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <div className="xl:col-span-2 space-y-5">
          <div className="glass-panel p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold text-white">Interactive Risk Map</h2>
                <p className="text-xs text-slate-500">Click any region to inspect atmospheric predictors</p>
              </div>
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
                <Crosshair className="w-3 h-3" />
                <span>{grid.length} grid cells</span>
              </div>
            </div>
            <RiskMap grid={grid} onSelectCell={setSelectedCell} selectedHour={selectedHour} height="520px" />
          </div>

          <ForecastTimeline series={forecast} selectedHour={selectedHour} onHourChange={setSelectedHour} />
        </div>

        <div className="space-y-5">
          {selectedCell && cellTriggers ? (
            <>
              <div className="glass-panel p-4">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="w-4 h-4 text-primary-400" />
                  <h3 className="text-sm font-semibold text-white">Selected Region</h3>
                </div>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Coordinates</span>
                    <span className="stat-value text-slate-300">
                      {selectedCell.lat.toFixed(2)}°N, {selectedCell.lng.toFixed(2)}°E
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Risk Probability</span>
                    <span className="stat-value" style={{ color: SEVERITY_META[cellTriggers.severity].color }}>
                      {(selectedCell.risk * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Predicted Event</span>
                    <span className="text-slate-300 font-medium" style={{ color: EVENT_META[cellTriggers.type].color }}>
                      {EVENT_META[cellTriggers.type].shortLabel}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Severity Class</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                      style={{ color: SEVERITY_META[cellTriggers.severity].color, background: SEVERITY_META[cellTriggers.severity].bg }}>
                      {SEVERITY_META[cellTriggers.severity].label}
                    </span>
                  </div>
                </div>
              </div>

              <AtmosphericPanel triggers={cellTriggers.triggers} />

              <XAIPanel
                eventType={cellTriggers.type}
                triggers={cellTriggers.triggers}
                probability={selectedCell.risk}
                locationName={`${selectedCell.lat.toFixed(2)}°N, ${selectedCell.lng.toFixed(2)}°E`}
              />
            </>
          ) : (
            <div className="glass-panel p-8 text-center">
              <Crosshair className="w-8 h-8 text-slate-600 mx-auto mb-3" />
              <h3 className="text-sm font-medium text-slate-400 mb-1">No Region Selected</h3>
              <p className="text-xs text-slate-600">
                Click on the risk map to inspect atmospheric predictors and model explanations for any location.
              </p>
            </div>
          )}

          {/* Nearby alerts */}
          {alerts.length > 0 && (
            <div className="glass-panel p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Active Alert Locations</h3>
              <div className="space-y-2">
                {alerts.map((a) => (
                  <div key={a.id} className="flex items-center gap-2 text-xs p-2 rounded-md bg-ink-800/40">
                    <div className="w-2 h-2 rounded-full" style={{ background: EVENT_META[a.event_type].color }} />
                    <span className="text-slate-300 flex-1">{a.location_name}</span>
                    <span className="stat-value text-slate-500">{(a.probability * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
