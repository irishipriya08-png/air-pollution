import { useState } from 'react';
import { useSubscriptions } from '@/hooks/useData';
import { EVENT_META } from '@/lib/predictionEngine';
import { UserPlus, Trash2, Phone, Mail, MapPin, Bell } from 'lucide-react';
import type { EventType } from '@/types';

const INDIAN_STATES = [
  'Uttarakhand', 'Himachal Pradesh', 'Rajasthan', 'Bihar', 'Maharashtra',
  'Karnataka', 'Kerala', 'Tamil Nadu', 'Assam', 'West Bengal', 'Gujarat',
  'Punjab', 'Haryana', 'Uttar Pradesh', 'Madhya Pradesh', 'Jharkhand',
  'Odisha', 'Chhattisgarh', 'Telangana', 'Andhra Pradesh', 'Jammu & Kashmir',
];

export function SubscriptionsView() {
  const { subs, loading, add, remove } = useSubscriptions();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    contact_name: '',
    phone: '',
    email: '',
    district: '',
    state: 'Uttarakhand',
    alert_types: ['thunderstorm', 'cloudburst', 'flash_flood'] as string[],
  });

  const toggleAlertType = (type: string) => {
    setForm((prev) => ({
      ...prev,
      alert_types: prev.alert_types.includes(type)
        ? prev.alert_types.filter((t) => t !== type)
        : [...prev.alert_types, type],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.contact_name || !form.district) return;
    await add({
      contact_name: form.contact_name,
      phone: form.phone || null,
      email: form.email || null,
      district: form.district,
      state: form.state,
      alert_types: form.alert_types,
    });
    setForm({
      contact_name: '', phone: '', email: '', district: '', state: 'Uttarakhand',
      alert_types: ['thunderstorm', 'cloudburst', 'flash_flood'],
    });
    setShowForm(false);
  };

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold text-white">Alert Subscriptions</h2>
          <p className="text-xs text-slate-500">Register first responders and vulnerable communities for automated alerts</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary-500/10 border border-primary-500/20 text-xs font-medium text-primary-300 hover:bg-primary-500/20 transition-colors"
        >
          <UserPlus className="w-3.5 h-3.5" />
          {showForm ? 'Cancel' : 'Add Subscriber'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="glass-panel p-5 space-y-4 animate-slide-up">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Contact Name *</label>
              <input
                type="text"
                required
                value={form.contact_name}
                onChange={(e) => setForm({ ...form, contact_name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-ink-800 border border-ink-700 text-sm text-white focus:border-primary-500/50 focus:outline-none transition-colors"
                placeholder="e.g. District Disaster Management Office"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">District *</label>
              <input
                type="text"
                required
                value={form.district}
                onChange={(e) => setForm({ ...form, district: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-ink-800 border border-ink-700 text-sm text-white focus:border-primary-500/50 focus:outline-none transition-colors"
                placeholder="e.g. Chamoli"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Phone</label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-ink-800 border border-ink-700 text-sm text-white focus:border-primary-500/50 focus:outline-none transition-colors"
                placeholder="+91 XXXXX XXXXX"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-ink-800 border border-ink-700 text-sm text-white focus:border-primary-500/50 focus:outline-none transition-colors"
                placeholder="responder@ndma.gov.in"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-400 mb-1.5">State</label>
              <select
                value={form.state}
                onChange={(e) => setForm({ ...form, state: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-ink-800 border border-ink-700 text-sm text-white focus:border-primary-500/50 focus:outline-none transition-colors"
              >
                {INDIAN_STATES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-2">Alert Types</label>
            <div className="flex flex-wrap gap-2">
              {(['thunderstorm', 'cloudburst', 'flash_flood'] as EventType[]).map((type) => {
                const meta = EVENT_META[type];
                const selected = form.alert_types.includes(type);
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => toggleAlertType(type)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      selected ? 'bg-ink-700/60 text-white' : 'bg-ink-800/30 text-slate-500 border-ink-700/40'
                    }`}
                    style={selected ? { borderColor: `${meta.color}40` } : {}}
                  >
                    <span className="w-2 h-2 rounded-full" style={{ background: meta.color }} />
                    {meta.shortLabel}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-primary-500/20 border border-primary-500/30 text-sm font-medium text-primary-300 hover:bg-primary-500/30 transition-colors"
          >
            Register Subscriber
          </button>
        </form>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="glass-panel p-3 text-center">
          <div className="stat-value text-xl text-white">{subs.length}</div>
          <div className="text-[10px] text-slate-500 uppercase tracking-wide mt-0.5">Total Subscribers</div>
        </div>
        <div className="glass-panel p-3 text-center">
          <div className="stat-value text-xl text-white">{subs.filter((s) => s.alert_types.includes('cloudburst')).length}</div>
          <div className="text-[10px] text-slate-500 uppercase tracking-wide mt-0.5">Cloudburst Alerts</div>
        </div>
        <div className="glass-panel p-3 text-center">
          <div className="stat-value text-xl text-white">{subs.filter((s) => s.alert_types.includes('thunderstorm')).length}</div>
          <div className="text-[10px] text-slate-500 uppercase tracking-wide mt-0.5">Thunderstorm Alerts</div>
        </div>
        <div className="glass-panel p-3 text-center">
          <div className="stat-value text-xl text-white">{subs.filter((s) => s.alert_types.includes('flash_flood')).length}</div>
          <div className="text-[10px] text-slate-500 uppercase tracking-wide mt-0.5">Flash Flood Alerts</div>
        </div>
      </div>

      {loading ? (
        <div className="glass-panel p-12 text-center text-sm text-slate-500">Loading subscribers...</div>
      ) : subs.length === 0 ? (
        <div className="glass-panel p-12 text-center">
          <Bell className="w-8 h-8 text-slate-600 mx-auto mb-3" />
          <p className="text-sm text-slate-400 mb-1">No subscribers registered yet</p>
          <p className="text-xs text-slate-600">Add first responders and community contacts to start sending automated alerts</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {subs.map((sub) => (
            <div key={sub.id} className="glass-panel glass-panel-hover p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="text-sm font-semibold text-white">{sub.contact_name}</div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    <span className="text-xs text-slate-400">{sub.district}, {sub.state}</span>
                  </div>
                </div>
                <button
                  onClick={() => remove(sub.id)}
                  className="text-slate-600 hover:text-danger-400 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-1 text-[11px] text-slate-500">
                {sub.phone && (
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3 h-3" />
                    <span>{sub.phone}</span>
                  </div>
                )}
                {sub.email && (
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-3 h-3" />
                    <span>{sub.email}</span>
                  </div>
                )}
              </div>
              <div className="flex flex-wrap gap-1 mt-2.5">
                {sub.alert_types.map((type) => {
                  const meta = EVENT_META[type as EventType];
                  return (
                    <span key={type} className="text-[9px] font-mono px-1.5 py-0.5 rounded"
                      style={{ color: meta.color, background: `${meta.color}15` }}>
                      {meta.shortLabel}
                    </span>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
