import { CloudLightning, CloudRain, Waves, Zap, Gauge as GaugeIcon, Map as MapIcon } from 'lucide-react';
import { StatCard } from '@/components/StatCard';
import { RiskMap } from '@/components/RiskMap';
import { AtmosphericPanel } from '@/components/AtmosphericPanel';
import { AlertCard } from '@/components/AlertCard';
import { ForecastTimeline } from '@/components/ForecastTimeline';
import { XAIPanel } from '@/components/XAIPanel';
import { useAlerts, useMetrics, useRiskGrid, useForecastSeries, useVariableHistory } from '@/hooks/useData';
import { useState, useMemo } from 'react';
import type { GridCell } from '@/types';
import { generateTriggers, classifySeverity } from '@/lib/predictionEngine';

export function DashboardView() {
  const { alerts, loading, acknowledge, dismiss } = useAlerts();
  const { metrics } = useMetrics();
  const forecast = useForecastSeries();
  const history = useVariableHistory();
  const [selectedHour, setSelectedHour] = useState(0);
  const grid = useRiskGrid(selectedHour);

  const [selectedCell, setSelectedCell] = useState<GridCell | null>(null);

  const currentTriggers = useMemo(() => {
    if (alerts.length > 0) return alerts[0].meteorological_triggers;
    if (selectedCell) return generateTriggers('thunderstorm', selectedCell.risk);
    const latest = history[history.length - 1];
    if (latest) {
      return { iwv: latest.iwv, cape: latest.cape, cin: latest.cin, ctt_drop: latest.ctt, convergence: latest.convergence, shear: latest.shear };
    }
    return { iwv: 30, cape: 2000, cin: -40, ctt_drop: -4, convergence: 0.6, shear: 15 };
  }, [alerts, selectedCell, history]);

  const criticalCount = alerts.filter((a) => a.severity === 'critical').length;
  const primaryAlert = alerts[0];

  const handleSelectCell = (cell: GridCell) => {
    setSelectedCell(cell);
  };

  return (
    <div className="p-6 space-y-5">
      {/* Top stat row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard
          label="Active Alerts"
          value={alerts.length}
          icon={Zap}
          color="#ef4444"
          trend={{ value: `${criticalCount} critical`, direction: criticalCount > 0 ? 'up' : 'neutral' }}
        />
        <StatCard
          label="Thunderstorms"
          value={alerts.filter((a) => a.event_type === 'thunderstorm').length}
          icon={CloudLightning}
          color="#f59e0b"
        />
        <StatCard
          label="Cloudbursts"
          value={alerts.filter((a) => a.event_type === 'cloudburst').length}
          icon={CloudRain}
          color="#ef4444"
        />
        <StatCard
          label="Flash Floods"
          value={alerts.filter((a) => a.event_type === 'flash_flood').length}
          icon={Waves}
          color="#3b82f6"
        />
        <StatCard
          label="Inference"
          value={metrics?.inference_latency_ms ?? '—'}
          unit="ms"
          icon={GaugeIcon}
          color="#22d3ee"
          subtitle="per cycle"
        />
        <StatCard
          label="Grid Cells"
          value={metrics ? (metrics.grid_cells_analyzed / 1000).toFixed(0) + 'K' : '—'}
          icon={MapIcon}
          color="#34d399"
          subtitle="analyzed"
        />
      </div>

      {/* Main grid: map + side panels */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <div className="xl:col-span-2 space-y-5">
          <div className="glass-panel p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold text-white">National Risk Map</h2>
                <p className="text-xs text-slate-500">Multi-task probability output · INSAT-3D + IMDAA fusion</p>
              </div>
            </div>
            <RiskMap grid={grid} onSelectCell={handleSelectCell} selectedHour={selectedHour} height="420px" />
          </div>

          <ForecastTimeline series={forecast} selectedHour={selectedHour} onHourChange={setSelectedHour} />
        </div>

        <div className="space-y-5">
          <AtmosphericPanel triggers={currentTriggers} />

          {primaryAlert && (
            <XAIPanel
              eventType={primaryAlert.event_type}
              triggers={primaryAlert.meteorological_triggers}
              probability={primaryAlert.probability}
              locationName={primaryAlert.location_name}
            />
          )}
        </div>
      </div>

      {/* Alert feed */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-white">Priority Alerts</h2>
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
            {alerts.length} active
          </span>
        </div>
        {loading ? (
          <div className="glass-panel p-8 text-center text-sm text-slate-500">Loading alerts...</div>
        ) : alerts.length === 0 ? (
          <div className="glass-panel p-8 text-center text-sm text-slate-500">No active alerts. All clear.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {alerts.slice(0, 6).map((alert) => (
              <AlertCard key={alert.id} alert={alert} onAcknowledge={acknowledge} onDismiss={dismiss} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
