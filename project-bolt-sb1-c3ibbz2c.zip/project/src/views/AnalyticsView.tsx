import { useMemo } from 'react';
import { useVariableHistory, useMetrics } from '@/hooks/useData';
import { StatCard } from '@/components/StatCard';
import { Activity, Cpu, Target, Database, TrendingUp, Gauge as GaugeIcon } from 'lucide-react';

const VAR_CONFIG = [
  { key: 'iwv' as const, label: 'Integrated Water Vapor', unit: 'kg/m²', color: '#22d3ee', max: 60 },
  { key: 'cape' as const, label: 'CAPE', unit: 'J/kg', color: '#f59e0b', max: 4000 },
  { key: 'cin' as const, label: 'CIN', unit: 'J/kg', color: '#a78bfa', max: 0, min: -150 },
  { key: 'ctt' as const, label: 'Cloud Top Temp', unit: '°C', color: '#60a5fa', max: 10, min: -40 },
  { key: 'convergence' as const, label: 'Convergence', unit: 'idx', color: '#34d399', max: 1 },
  { key: 'precipitation' as const, label: 'Precipitation (QPE)', unit: 'mm', color: '#3b82f6', max: 60 },
];

function LineChart({ data, color, max, min = 0, label, unit }: {
  data: number[];
  color: string;
  max: number;
  min?: number;
  label: string;
  unit: string;
}) {
  const w = 100;
  const h = 100;
  const range = max - min;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x},${y}`;
  });

  const current = data[data.length - 1];
  const previous = data[0];
  const delta = current - previous;
  const deltaPct = ((delta / Math.abs(previous)) * 100).toFixed(1);

  return (
    <div className="glass-panel p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium text-slate-300">{label}</span>
        <div className="flex items-center gap-2">
          <span className="stat-value text-sm" style={{ color }}>{current < 0 ? current.toFixed(1) : Math.round(current)}</span>
          <span className="text-[10px] font-mono text-slate-500">{unit}</span>
        </div>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-20" preserveAspectRatio="none">
        <defs>
          <linearGradient id={`grad-${label.replace(/\s/g, '')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <polygon
          points={`0,${h} ${points.join(' ')} ${w},${h}`}
          fill={`url(#grad-${label.replace(/\s/g, '')})`}
        />
        <polyline
          points={points.join(' ')}
          fill="none"
          stroke={color}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          vectorEffect="non-scaling-stroke"
        />
      </svg>
      <div className="flex items-center justify-between mt-1 text-[10px] font-mono">
        <span className="text-slate-600">24h trend</span>
        <span style={{ color: delta > 0 ? '#ef4444' : '#22c55e' }}>
          {delta > 0 ? '↑' : '↓'} {Math.abs(parseFloat(deltaPct))}%
        </span>
      </div>
    </div>
  );
}

export function AnalyticsView() {
  const history = useVariableHistory();
  const { metrics } = useMetrics();

  const chartData = useMemo(() => {
    return VAR_CONFIG.map((cfg) => ({
      ...cfg,
      data: history.map((r) => r[cfg.key]),
    }));
  }, [history]);

  return (
    <div className="p-6 space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard
          label="Model"
          value={metrics?.model_version ?? 'NowCastNet-v2.1'}
          icon={Cpu}
          color="#22d3ee"
        />
        <StatCard
          label="Accuracy"
          value={metrics?.accuracy_pct.toFixed(1) ?? '91.2'}
          unit="%"
          icon={Target}
          color="#22c55e"
          trend={{ value: '+2.3%', direction: 'up' }}
        />
        <StatCard
          label="Latency"
          value={metrics?.inference_latency_ms ?? 340}
          unit="ms"
          icon={GaugeIcon}
          color="#f59e0b"
          subtitle="real-time"
        />
        <StatCard
          label="Coverage"
          value="3.29M"
          unit="km²"
          icon={Activity}
          color="#60a5fa"
          subtitle="pan-India"
        />
        <StatCard
          label="Grid Cells"
          value="128K"
          icon={Database}
          color="#34d399"
          subtitle="4km resolution"
        />
        <StatCard
          label="Data Sources"
          value="5"
          icon={TrendingUp}
          color="#fb923c"
          subtitle="multi-modal"
        />
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-semibold text-white">Atmospheric Variable Trends</h2>
            <p className="text-xs text-slate-500">24-hour observation window · INSAT-3D/3DR + IMDAA</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {chartData.map((chart) => (
            <LineChart
              key={chart.key}
              data={chart.data}
              color={chart.color}
              max={chart.max}
              min={chart.min ?? 0}
              label={chart.label}
              unit={chart.unit}
            />
          ))}
        </div>
      </div>

      <div className="glass-panel p-4">
        <h3 className="text-sm font-semibold text-white mb-3">Data Fusion Pipeline</h3>
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {[
            { name: 'INSAT-3D/3DR WV', desc: 'Water Vapor' },
            { name: 'INSAT TIR', desc: 'Cloud Top Temp' },
            { name: 'IMDAA Reanalysis', desc: 'Thermodynamics' },
            { name: 'QPE Satellite', desc: 'Precipitation' },
            { name: 'CartoDEM', desc: 'Topography' },
          ].map((src, i, arr) => (
            <div key={src.name} className="flex items-center gap-2">
              <div className="px-3 py-2 rounded-lg bg-ink-800/60 border border-ink-700/40">
                <div className="font-medium text-slate-300">{src.name}</div>
                <div className="text-[10px] text-slate-600 font-mono">{src.desc}</div>
              </div>
              {i < arr.length - 1 && i !== arr.length - 1 && (
                <span className="text-primary-500 text-lg">→</span>
              )}
            </div>
          ))}
          <span className="text-primary-500 text-lg">→</span>
          <div className="px-3 py-2 rounded-lg bg-primary-500/10 border border-primary-500/30">
            <div className="font-medium text-primary-300">Spatiotemporal Transformer</div>
            <div className="text-[10px] text-primary-600 font-mono">Multi-Task Inference</div>
          </div>
          <span className="text-primary-500 text-lg">→</span>
          <div className="px-3 py-2 rounded-lg bg-success-500/10 border border-success-500/30">
            <div className="font-medium text-success-400">Risk Maps + Alerts</div>
            <div className="text-[10px] text-success-600 font-mono">2-6h Nowcast</div>
          </div>
        </div>
      </div>
    </div>
  );
}
