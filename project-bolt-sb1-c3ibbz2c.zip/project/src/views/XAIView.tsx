import { useAlerts } from '@/hooks/useData';
import { XAIPanel } from '@/components/XAIPanel';
import { EVENT_META, SEVERITY_META } from '@/lib/predictionEngine';
import { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import type { WeatherAlert } from '@/types';

export function XAIView() {
  const { alerts, loading } = useAlerts();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const selected: WeatherAlert | null = alerts.find((a) => a.id === selectedId) ?? alerts[0] ?? null;

  if (loading) {
    return <div className="p-6"><div className="glass-panel p-12 text-center text-sm text-slate-500">Loading model explanations...</div></div>;
  }

  if (!selected) {
    return <div className="p-6"><div className="glass-panel p-12 text-center text-sm text-slate-500">No active alerts to explain.</div></div>;
  }

  return (
    <div className="p-6 space-y-5">
      <div>
        <h2 className="text-sm font-semibold text-white">Explainable AI Module</h2>
        <p className="text-xs text-slate-500">
          Transparent attribution of meteorological triggers for each prediction · SHAP-based feature importance
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Alert selector */}
        <div className="space-y-2">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mb-2">Active Predictions</div>
          {alerts.map((alert) => {
            const meta = EVENT_META[alert.event_type];
            const sev = SEVERITY_META[alert.severity];
            const isSelected = alert.id === selected.id;
            return (
              <button
                key={alert.id}
                onClick={() => setSelectedId(alert.id)}
                className={`w-full text-left p-3 rounded-lg border transition-all ${
                  isSelected
                    ? 'bg-ink-750/60 border-primary-500/30'
                    : 'bg-ink-800/40 border-ink-700/40 hover:border-ink-600/60'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-white">{meta.shortLabel}</span>
                  <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded"
                    style={{ color: sev.color, background: sev.bg }}>
                    {sev.label}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500">{alert.location_name}</div>
                <div className="flex items-center justify-between mt-1.5">
                  <span className="stat-value text-sm" style={{ color: meta.color }}>
                    {(alert.probability * 100).toFixed(0)}%
                  </span>
                  <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isSelected ? 'text-primary-400 translate-x-0.5' : 'text-slate-600'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* XAI detail */}
        <div className="lg:col-span-2">
          <XAIPanel
            eventType={selected.event_type}
            triggers={selected.meteorological_triggers}
            probability={selected.probability}
            locationName={selected.location_name}
          />

          <div className="glass-panel p-4 mt-4">
            <h3 className="text-sm font-semibold text-white mb-3">Meteorological Trigger Summary</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(selected.meteorological_triggers).map(([key, val]) => (
                <div key={key} className="p-2.5 rounded-md bg-ink-800/40 border border-ink-700/30">
                  <div className="text-[10px] font-mono uppercase tracking-wide text-slate-600 mb-0.5">{key}</div>
                  <div className="stat-value text-base text-slate-200">
                    {typeof val === 'number' ? (val < 0 ? val.toFixed(1) : Math.round(val)) : val}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
