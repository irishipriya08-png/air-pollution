import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon: LucideIcon;
  color?: string;
  trend?: { value: string; direction: 'up' | 'down' | 'neutral' };
  subtitle?: string;
}

export function StatCard({ label, value, unit, icon: Icon, color = '#22d3ee', trend, subtitle }: StatCardProps) {
  const trendColor = trend?.direction === 'up' ? '#ef4444' : trend?.direction === 'down' ? '#22c55e' : '#94a3b8';

  return (
    <div className="glass-panel glass-panel-hover p-4">
      <div className="flex items-start justify-between mb-2">
        <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wide">{label}</div>
        <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${color}15` }}>
          <Icon className="w-3.5 h-3.5" style={{ color }} />
        </div>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="stat-value text-2xl text-white">{value}</span>
        {unit && <span className="text-xs text-slate-500 font-mono">{unit}</span>}
      </div>
      {trend && (
        <div className="flex items-center gap-1.5 mt-1.5">
          <span className="text-[10px] font-mono" style={{ color: trendColor }}>
            {trend.direction === 'up' ? '↑' : trend.direction === 'down' ? '↓' : '→'} {trend.value}
          </span>
          {subtitle && <span className="text-[10px] text-slate-600">{subtitle}</span>}
        </div>
      )}
      {!trend && subtitle && <div className="text-[10px] text-slate-600 mt-1">{subtitle}</div>}
    </div>
  );
}
