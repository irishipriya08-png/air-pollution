import { useEffect, useState } from 'react';
import { Activity, Clock, Cpu, RefreshCw } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle: string;
  inferenceLatency: number;
  accuracy: number;
  onRefresh: () => void;
}

export function Header({ title, subtitle, inferenceLatency, accuracy, onRefresh }: HeaderProps) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const timeStr = now.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: 'Asia/Kolkata',
  });

  const dateStr = now.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    timeZone: 'Asia/Kolkata',
  });

  return (
    <header className="h-16 border-b border-ink-700/60 bg-ink-900/60 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-30">
      <div>
        <h1 className="text-base font-semibold text-white tracking-tight">{title}</h1>
        <p className="text-xs text-slate-500">{subtitle}</p>
      </div>

      <div className="flex items-center gap-5">
        <div className="hidden md:flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5 text-primary-400" />
            <span className="text-slate-500">Inference</span>
            <span className="stat-value text-primary-300">{inferenceLatency}ms</span>
          </div>
          <div className="w-px h-4 bg-ink-700" />
          <div className="flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-success-500" />
            <span className="text-slate-500">Accuracy</span>
            <span className="stat-value text-success-400">{accuracy.toFixed(1)}%</span>
          </div>
          <div className="w-px h-4 bg-ink-700" />
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span className="stat-value text-slate-300">{timeStr}</span>
            <span className="text-slate-600 text-[10px]">IST</span>
          </div>
          <div className="w-px h-4 bg-ink-700" />
          <span className="text-slate-500 text-[11px]">{dateStr}</span>
        </div>

        <button
          onClick={onRefresh}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-ink-800 hover:bg-ink-750 border border-ink-700 text-xs font-medium text-slate-300 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Refresh</span>
        </button>
      </div>
    </header>
  );
}
