import {
  CloudLightning,
  LayoutDashboard,
  Map,
  BarChart3,
  Bell,
  Brain,
  Users,
  Radio,
} from 'lucide-react';
import type { ViewKey } from '@/types';

interface SidebarProps {
  activeView: ViewKey;
  onNavigate: (view: ViewKey) => void;
  alertCount: number;
}

const NAV_ITEMS: { key: ViewKey; label: string; icon: typeof LayoutDashboard }[] = [
  { key: 'dashboard', label: 'Command Center', icon: LayoutDashboard },
  { key: 'map', label: 'Risk Maps', icon: Map },
  { key: 'analytics', label: 'Analytics', icon: BarChart3 },
  { key: 'alerts', label: 'Alert Feed', icon: Bell },
  { key: 'xai', label: 'Explainable AI', icon: Brain },
  { key: 'subscriptions', label: 'Subscribers', icon: Users },
];

export function Sidebar({ activeView, onNavigate, alertCount }: SidebarProps) {
  return (
    <aside className="w-60 shrink-0 bg-ink-900 border-r border-ink-700/60 flex flex-col h-screen sticky top-0">
      <div className="flex items-center gap-3 px-5 h-16 border-b border-ink-700/60">
        <div className="relative">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-400 to-primary-700 flex items-center justify-center glow-cyan">
            <CloudLightning className="w-5 h-5 text-ink-950" />
          </div>
          <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-success-500 rounded-full ring-2 ring-ink-900 animate-pulse" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-bold text-white tracking-wide">NowCast AI</div>
          <div className="text-[10px] text-primary-400 font-mono uppercase tracking-wider">Engine v2.1</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = activeView === item.key;
          const Icon = item.icon;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-primary-500/10 text-primary-300 border border-primary-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-ink-800/60 border border-transparent'
              }`}
            >
              <Icon className={`w-[18px] h-[18px] ${isActive ? 'text-primary-400' : ''}`} />
              <span className="flex-1 text-left">{item.label}</span>
              {item.key === 'alerts' && alertCount > 0 && (
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full bg-danger-500 text-white">
                  {alertCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="px-3 py-4 border-t border-ink-700/60 space-y-3">
        <div className="px-3 py-2.5 rounded-lg bg-ink-850/60 border border-ink-700/40">
          <div className="flex items-center gap-2 mb-1.5">
            <Radio className="w-3.5 h-3.5 text-success-500 animate-pulse" />
            <span className="text-[10px] font-mono uppercase tracking-wider text-success-500">Live Feed</span>
          </div>
          <div className="text-[10px] text-slate-500 leading-relaxed">
            INSAT-3D/3DR · IMDAA · CartoDEM
          </div>
        </div>
        <div className="px-3 text-[10px] text-slate-600 font-mono">
          Smart India Hackathon
        </div>
      </div>
    </aside>
  );
}
