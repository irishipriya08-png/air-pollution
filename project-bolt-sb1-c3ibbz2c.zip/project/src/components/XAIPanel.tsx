import { Brain, Zap } from 'lucide-react';
import type { EventType, MeteorologicalTriggers } from '@/types';
import { generateXAIContributions, EVENT_META } from '@/lib/predictionEngine';

interface XAIPanelProps {
  eventType: EventType;
  triggers: MeteorologicalTriggers;
  probability: number;
  locationName: string;
}

const STATUS_COLORS = {
  breached: { color: '#ef4444', label: 'Threshold Breached' },
  approaching: { color: '#f59e0b', label: 'Approaching' },
  normal: { color: '#22c55e', label: 'Within Range' },
};

export function XAIPanel({ eventType, triggers, probability, locationName }: XAIPanelProps) {
  const contributions = generateXAIContributions(eventType, triggers);
  const meta = EVENT_META[eventType];

  return (
    <div className="glass-panel p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary-400" />
          <h3 className="text-sm font-semibold text-white">Explainable AI</h3>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-primary-500/10 border border-primary-500/20">
          <Zap className="w-3 h-3 text-primary-400" />
          <span className="text-[10px] font-mono text-primary-300">SHAP Attribution</span>
        </div>
      </div>

      <div className="mb-4 pb-3 border-b border-ink-700/40">
        <div className="text-xs text-slate-500 mb-1">Prediction for</div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-white">{locationName}</span>
          <span className="text-xs px-2 py-0.5 rounded font-medium" style={{ color: meta.color, background: `${meta.color}15` }}>
            {meta.shortLabel}
          </span>
          <span className="stat-value text-sm ml-auto" style={{ color: meta.color }}>
            {(probability * 100).toFixed(0)}%
          </span>
        </div>
      </div>

      <div className="space-y-2.5">
        {contributions.map((c) => {
          const status = STATUS_COLORS[c.status];
          return (
            <div key={c.variable} className="group">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-slate-300">{c.label}</span>
                  <span
                    className="text-[9px] font-mono px-1.5 py-0.5 rounded"
                    style={{ color: status.color, background: `${status.color}15` }}
                  >
                    {status.label}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">
                  {c.value} <span className="text-slate-600">· {c.threshold}</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-ink-700/40 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${c.contribution * 100}%`,
                      background: `linear-gradient(90deg, ${status.color}80, ${status.color})`,
                    }}
                  />
                </div>
                <span className="text-[10px] font-mono text-slate-500 w-10 text-right">
                  {(c.contribution * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 pt-3 border-t border-ink-700/40">
        <div className="text-[10px] font-mono uppercase tracking-wider text-slate-600 mb-1.5">Model Reasoning</div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          The model attributes the highest influence to{' '}
          <span style={{ color: contributions[0]?.status === 'breached' ? '#ef4444' : '#f59e0b' }}>
            {contributions[0]?.label}
          </span>
          {' '}and{' '}
          <span style={{ color: contributions[1]?.status === 'breached' ? '#ef4444' : '#f59e0b' }}>
            {contributions[1]?.label}
          </span>
          , both of which {contributions[0]?.status === 'breached' || contributions[1]?.status === 'breached' ? 'have breached their signature thresholds' : 'are approaching critical levels'},
          indicating a {probability > 0.7 ? 'high-confidence' : 'moderate-confidence'} nowcast for this event.
        </p>
      </div>
    </div>
  );
}
