import { useEffect, useRef, useState } from 'react';
import { Maximize2, Eye, Layers } from 'lucide-react';
import type { GridCell } from '@/types';
import { riskToColor, getHotspots, EVENT_META } from '@/lib/predictionEngine';
import type { EventType } from '@/types';

interface RiskMapProps {
  grid: GridCell[];
  onSelectCell?: (cell: GridCell) => void;
  selectedHour: number;
  className?: string;
  height?: string;
}

const INDIA_BOUNDS = { minLat: 6, maxLat: 37, minLng: 68, maxLng: 97 };

function project(lat: number, lng: number, w: number, h: number) {
  const x = ((lng - INDIA_BOUNDS.minLng) / (INDIA_BOUNDS.maxLng - INDIA_BOUNDS.minLng)) * w;
  const y = ((INDIA_BOUNDS.maxLat - lat) / (INDIA_BOUNDS.maxLat - INDIA_BOUNDS.minLat)) * h;
  return { x, y };
}

export function RiskMap({ grid, onSelectCell, selectedHour, className = '', height = '500px' }: RiskMapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState<GridCell | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [layers, setLayers] = useState({ heatmap: true, hotspots: true, grid: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const resize = () => {
      const rect = container.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
      draw();
    };

    const draw = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const w = canvas.width;
      const h = canvas.height;
      const dpr = window.devicePixelRatio;

      ctx.clearRect(0, 0, w, h);

      // Background
      ctx.fillStyle = '#0a1420';
      ctx.fillRect(0, 0, w, h);

      // Grid lines
      if (layers.grid) {
        ctx.strokeStyle = 'rgba(36, 58, 80, 0.3)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 10; i++) {
          const x = (w / 10) * i;
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, h);
          ctx.stroke();
          const y = (h / 10) * i;
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }
      }

      // Heatmap cells
      if (layers.heatmap) {
        const cellW = w / 40 * dpr;
        const cellH = h / 32 * dpr;
        for (const cell of grid) {
          const { x, y } = project(cell.lat, cell.lng, w, h);
          ctx.fillStyle = riskToColor(cell.risk);
          ctx.fillRect(x - cellW / 2, y - cellH / 2, cellW, cellH);
        }
      }

      // India outline (simplified path)
      ctx.strokeStyle = 'rgba(100, 130, 160, 0.5)';
      ctx.lineWidth = 1.5 * dpr;
      ctx.beginPath();
      const outline: [number, number][] = [
        [68, 24], [70, 23.5], [72, 24], [73, 25], [74, 27], [73.5, 28.5], [74, 30],
        [75, 32.5], [76, 34.5], [77, 35], [78.5, 35.2], [79, 34], [80, 34.5],
        [81, 32], [82, 31], [83, 30], [84, 28.5], [85, 27], [86, 25.5], [87, 24.5],
        [88, 23], [89, 22.5], [90, 22], [91, 22], [92, 21.5], [93, 22], [94, 22.5],
        [95, 23], [96, 24], [96.5, 25], [97, 26], [97, 27.5], [96, 28.5], [95, 29],
        [94, 29.5], [93.5, 28], [93, 27.5], [92, 26], [91, 25], [90, 24], [89, 23.5],
        [88.5, 22], [88, 21.5], [87, 21], [86, 20.5], [85, 20], [84, 19.5], [83, 18],
        [82.5, 17], [82, 16], [81, 15.5], [80, 15], [79, 13.5], [78, 12.5], [77.5, 11],
        [77, 10], [76.5, 9.5], [76, 8.5], [75.5, 8], [74.5, 8.5], [74, 10], [73, 11.5],
        [72.5, 13], [72, 14], [71, 16], [70.5, 18], [70, 20], [69, 22], [68, 23.5], [68, 24],
      ];
      for (let i = 0; i < outline.length; i++) {
        const [lng, lat] = outline[i];
        const { x, y } = project(lat, lng, w, h);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Hotspot markers
      if (layers.hotspots) {
        const hotspots = getHotspots();
        for (const hs of hotspots) {
          const { x, y } = project(hs.lat, hs.lng, w, h);
          const meta = EVENT_META[hs.type as EventType];

          // Pulsing ring
          const pulseRadius = (12 + Math.sin(Date.now() / 800) * 6) * dpr;
          ctx.strokeStyle = meta.color + '40';
          ctx.lineWidth = 2 * dpr;
          ctx.beginPath();
          ctx.arc(x, y, pulseRadius, 0, Math.PI * 2);
          ctx.stroke();

          // Inner dot
          ctx.fillStyle = meta.color;
          ctx.beginPath();
          ctx.arc(x, y, 5 * dpr, 0, Math.PI * 2);
          ctx.fill();

          // Glow
          ctx.shadowBlur = 15;
          ctx.shadowColor = meta.color;
          ctx.beginPath();
          ctx.arc(x, y, 3 * dpr, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);

    // Animation loop for pulsing hotspots
    let raf: number;
    const animate = () => {
      draw();
      raf = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      ro.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [grid, layers, selectedHour]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    setMousePos({ x: mx, y: my });

    // Find nearest cell
    const lng = INDIA_BOUNDS.minLng + (mx / rect.width) * (INDIA_BOUNDS.maxLng - INDIA_BOUNDS.minLng);
    const lat = INDIA_BOUNDS.maxLat - (my / rect.height) * (INDIA_BOUNDS.maxLat - INDIA_BOUNDS.minLat);

    let nearest: GridCell | null = null;
    let minDist = Infinity;
    for (const cell of grid) {
      const d = Math.sqrt(Math.pow(cell.lat - lat, 2) + Math.pow(cell.lng - lng, 2));
      if (d < minDist) {
        minDist = d;
        nearest = cell;
      }
    }
    setHovered(nearest);
  };

  const handleClick = () => {
    if (hovered && onSelectCell) onSelectCell(hovered);
  };

  return (
    <div className={`relative ${className}`}>
      <div ref={containerRef} className="relative w-full rounded-lg overflow-hidden bg-ink-950 grid-bg" style={{ height }}>
        <canvas
          ref={canvasRef}
          className="absolute inset-0 cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHovered(null)}
          onClick={handleClick}
        />

        {/* Layer toggles */}
        <div className="absolute top-3 right-3 flex items-center gap-1 bg-ink-900/80 backdrop-blur-md rounded-lg border border-ink-700/60 p-1">
          <Layers className="w-3.5 h-3.5 text-slate-500 ml-1.5 mr-1" />
          {(['heatmap', 'hotspots', 'grid'] as const).map((layer) => (
            <button
              key={layer}
              onClick={() => setLayers((p) => ({ ...p, [layer]: !p[layer] }))}
              className={`text-[10px] px-2 py-1 rounded font-mono uppercase tracking-wide transition-colors ${
                layers[layer] ? 'text-primary-300 bg-primary-500/10' : 'text-slate-600 hover:text-slate-400'
              }`}
            >
              {layer}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="absolute bottom-3 left-3 bg-ink-900/80 backdrop-blur-md rounded-lg border border-ink-700/60 px-3 py-2">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">Risk Level</div>
          <div className="flex items-center gap-1">
            {[
              { label: 'Low', color: 'rgba(34, 197, 94, 0.5)' },
              { label: 'Med', color: 'rgba(234, 179, 8, 0.5)' },
              { label: 'High', color: 'rgba(249, 115, 22, 0.6)' },
              { label: 'Severe', color: 'rgba(239, 68, 68, 0.7)' },
              { label: 'Extreme', color: 'rgba(220, 38, 38, 0.85)' },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-sm" style={{ background: s.color }} />
                <span className="text-[9px] text-slate-400 font-mono">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Hour indicator */}
        <div className="absolute top-3 left-3 bg-ink-900/80 backdrop-blur-md rounded-lg border border-ink-700/60 px-3 py-1.5">
          <div className="flex items-center gap-2">
            <Eye className="w-3.5 h-3.5 text-primary-400" />
            <span className="text-xs font-mono text-slate-300">
              T+{selectedHour}h Forecast
            </span>
          </div>
        </div>

        {/* Tooltip */}
        {hovered && (
          <div
            className="absolute pointer-events-none bg-ink-900/95 backdrop-blur-md border border-ink-600/60 rounded-lg px-3 py-2 text-xs shadow-xl z-20"
            style={{
              left: Math.min(mousePos.x + 14, 300),
              top: Math.min(mousePos.y + 14, 200),
            }}
          >
            <div className="font-mono text-slate-500 text-[10px] mb-1">
              {hovered.lat.toFixed(2)}°N, {hovered.lng.toFixed(2)}°E
            </div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-slate-400">Risk:</span>
              <span className="stat-value" style={{ color: riskToColor(hovered.risk).replace(/[\d.]+\)$/, '1)') }}>
                {(hovered.risk * 100).toFixed(0)}%
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
              IWV: {hovered.iwv.toFixed(1)} · CAPE: {Math.round(hovered.cape)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
