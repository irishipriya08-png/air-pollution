import { useState } from 'react';
import { Clock } from 'lucide-react';
import { EVENT_META } from '@/lib/predictionEngine';

interface ForecastTimelineProps {
  series: { hour: number; thunderstorm: number; cloudburst: number; flash_flood: number }[];
  selectedHour: number;
  onHourChange: (hour: number) => void;
}

export function ForecastTimeline({ series, selectedHour, onHourChange }: ForecastTimelineProps) {
  const [hovered, setHovered] = useState<number | null>(null);

  const maxVal = Math.max(...series.flatMap((s) => [s.thunderstorm, s.cloudburst, s.flash_flood]));

  return (
    <div className="glass-panel p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-primary-400" />
          <h3 className="text-sm font-semibold text-white">Forecast Horizon</h3>
        </div>
        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">2-6 Hour Nowcast</span>
      </div>

      {/* Timeline selector */}
      <div className="flex items-center gap-1 mb-4">
        {series.map((s) => (
          <button
            key={s.hour}
            onClick={() => onHourChange(s.hour)}
            onMouseEnter={() => setHovered(s.hour)}
            onMouseLeave={() => setHovered(null)}
            className={`flex-1 py-1.5 rounded-md text-[11px] font-mono font-medium transition-all ${
              selectedHour === s.hour
                ? 'bg-primary-500/15 text-primary-300 border border-primary-500/30'
                : 'text-slate-500 hover:text-slate-300 border border-transparent'
            }`}
          >
            +{s.hour}h
          </button>
        ))}
      </div>

      {/* Bar chart */}
      <div className="space-y-2.5">
        {(['thunderstorm', 'cloudburst', 'flash_flood'] as const).map((type) => {
          const meta = EVENT_META[type];
          return (
            <div key={type}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] text-slate-400">{meta.shortLabel}</span>
                {hovered !== null && (
                  <span className="text-[10px] font-mono" style={{ color: meta.color }}>
                    {(series[hovered][type] * 100).toFixed(0)}%
                  </span>
                )}
              </div>
              <div className="flex items-end gap-1 h-12">
                {series.map((s) => {
                  const heightPct = (s[type] / maxVal) * 100;
                  const isSelected = s.hour === selectedHour;
                  return (
                    <div
                      key={s.hour}
                      className="flex-1 flex items-end h-full"
                      onMouseEnter={() => setHovered(s.hour)}
                      onMouseLeave={() => setHovered(null)}
                    >
                      <div
                        className="w-full rounded-sm transition-all duration-300 cursor-pointer"
                        style={{
                          height: `${Math.max(heightPct, 4)}%`,
                          background: meta.color,
                          opacity: isSelected ? 1 : 0.45,
                          boxShadow: isSelected ? `0 0 8px ${meta.color}60` : 'none',
                        }}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex justify-between mt-1 text-[9px] font-mono text-slate-600">
        {series.map((s) => (
          <span key={s.hour} className="flex-1 text-center">+{s.hour}h</span>
        ))}
      </div>
    </div>
  );
}
