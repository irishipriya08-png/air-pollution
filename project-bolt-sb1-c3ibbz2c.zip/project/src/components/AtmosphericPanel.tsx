import { Droplets, Flame, Thermometer, Wind, ArrowDownUp, TrendingDown } from 'lucide-react';

interface GaugeProps {
  label: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  threshold?: number;
  icon: typeof Droplets;
  color: string;
  sublabel?: string;
}

export function Gauge({ label, value, unit, min, max, threshold, icon: Icon, color, sublabel }: GaugeProps) {
  const pct = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - pct);
  const isBreached = threshold !== undefined && value >= threshold;

  return (
    <div className="flex flex-col items-center p-3 rounded-lg bg-ink-800/40 border border-ink-700/40">
      <div className="relative w-[120px] h-[120px]">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle
            cx="60" cy="60" r={radius}
            fill="none"
            stroke="rgba(36, 58, 80, 0.4)"
            strokeWidth="6"
          />
          <circle
            cx="60" cy="60" r={radius}
            fill="none"
            stroke={color}
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
          />
          {threshold !== undefined && (
            <circle
              cx="60" cy="60" r={radius}
              fill="none"
              stroke="rgba(239, 68, 68, 0.5)"
              strokeWidth="2"
              strokeDasharray="2 4"
              strokeDashoffset={circumference * (1 - (threshold - min) / (max - min))}
            />
          )}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <Icon className={`w-4 h-4 mb-0.5 ${isBreached ? 'text-danger-400' : ''}`} style={{ color: isBreached ? undefined : color }} />
          <div className={`stat-value text-lg ${isBreached ? 'text-danger-400' : 'text-white'}`}>
            {value < 0 ? value.toFixed(1) : Math.round(value)}
          </div>
          <div className="text-[9px] text-slate-500 font-mono">{unit}</div>
        </div>
      </div>
      <div className="text-center mt-1">
        <div className="text-xs font-medium text-slate-300">{label}</div>
        {sublabel && <div className="text-[9px] text-slate-600 font-mono mt-0.5">{sublabel}</div>}
      </div>
    </div>
  );
}

interface AtmosphericPanelProps {
  triggers: {
    iwv: number;
    cape: number;
    cin: number;
    ctt_drop: number;
    convergence: number;
    shear: number;
  };
}

export function AtmosphericPanel({ triggers }: AtmosphericPanelProps) {
  return (
    <div className="glass-panel p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white">Atmospheric Predictors</h3>
        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Live</span>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-2.5">
        <Gauge
          label="Water Vapor"
          sublabel="IWV"
          value={triggers.iwv}
          unit="kg/m²"
          min={0}
          max={60}
          threshold={35}
          icon={Droplets}
          color="#22d3ee"
        />
        <Gauge
          label="CAPE"
          sublabel="Instability"
          value={triggers.cape}
          unit="J/kg"
          min={0}
          max={4000}
          threshold={2500}
          icon={Flame}
          color="#f59e0b"
        />
        <Gauge
          label="CIN"
          sublabel="Inhibition"
          value={triggers.cin}
          unit="J/kg"
          min={-150}
          max={0}
          threshold={-25}
          icon={TrendingDown}
          color="#a78bfa"
        />
        <Gauge
          label="CTT Drop"
          sublabel="Cloud Top Temp"
          value={triggers.ctt_drop}
          unit="K/min"
          min={-10}
          max={0}
          threshold={-5}
          icon={Thermometer}
          color="#60a5fa"
        />
        <Gauge
          label="Convergence"
          sublabel="Low-Level Lift"
          value={triggers.convergence}
          unit="index"
          min={0}
          max={1}
          threshold={0.75}
          icon={ArrowDownUp}
          color="#34d399"
        />
        <Gauge
          label="Wind Shear"
          sublabel="Vertical"
          value={triggers.shear}
          unit="m/s"
          min={0}
          max={40}
          threshold={15}
          icon={Wind}
          color="#fb923c"
        />
      </div>
    </div>
  );
}
