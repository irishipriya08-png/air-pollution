import { MapPin, Clock, AlertTriangle, Check, X } from 'lucide-react';
import type { WeatherAlert } from '@/types';
import { EVENT_META, SEVERITY_META } from '@/lib/predictionEngine';

interface AlertCardProps {
  alert: WeatherAlert;
  onAcknowledge?: (id: string) => void;
  onDismiss?: (id: string) => void;
  compact?: boolean;
}

export function AlertCard({ alert, onAcknowledge, onDismiss, compact = false }: AlertCardProps) {
  const eventMeta = EVENT_META[alert.event_type];
  const sevMeta = SEVERITY_META[alert.severity];
  const isCritical = alert.severity === 'critical';

  return (
    <div
      className={`relative rounded-lg border p-4 transition-all duration-200 animate-slide-up ${
        isCritical ? 'border-danger-500/40 bg-danger-500/5' : 'border-ink-700/60 bg-ink-800/40'
      }`}
    >
      {isCritical && (
        <div className="absolute top-0 left-0 w-1 h-full rounded-l-lg bg-danger-500" />
      )}

      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ background: `${eventMeta.color}20`, border: `1px solid ${eventMeta.color}40` }}
          >
            <AlertTriangle className="w-4 h-4" style={{ color: eventMeta.color }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white">{eventMeta.label}</span>
              <span
                className="text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded"
                style={{ color: sevMeta.color, background: sevMeta.bg }}
              >
                {sevMeta.label}
              </span>
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              <MapPin className="w-3 h-3 text-slate-500" />
              <span className="text-xs text-slate-400">{alert.location_name}</span>
            </div>
          </div>
        </div>

        {!compact && (
          <div className="text-right shrink-0">
            <div className="stat-value text-lg" style={{ color: eventMeta.color }}>
              {(alert.probability * 100).toFixed(0)}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">probability</div>
          </div>
        )}
      </div>

      {!compact && (
        <p className="text-xs text-slate-400 leading-relaxed mb-3">{alert.description}</p>
      )}

      <div className="flex items-center gap-3 text-[10px] font-mono text-slate-500">
        <div className="flex items-center gap-1">
          <Clock className="w-3 h-3" />
          <span>T+{alert.lead_time_hours}h lead time</span>
        </div>
        <span>·</span>
        <span>{alert.lat.toFixed(2)}°N, {alert.lng.toFixed(2)}°E</span>
        {alert.status === 'acknowledged' && (
          <>
            <span>·</span>
            <span className="text-success-500">Acknowledged</span>
          </>
        )}
      </div>

      {!compact && onAcknowledge && alert.status === 'active' && (
        <div className="flex items-center gap-2 mt-3">
          <button
            onClick={() => onAcknowledge(alert.id)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-ink-700/60 hover:bg-ink-600/60 text-[11px] font-medium text-slate-300 transition-colors"
          >
            <Check className="w-3 h-3" />
            Acknowledge
          </button>
          {onDismiss && (
            <button
              onClick={() => onDismiss(alert.id)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-ink-700/60 hover:bg-ink-600/60 text-[11px] font-medium text-slate-300 transition-colors"
            >
              <X className="w-3 h-3" />
              Dismiss
            </button>
          )}
        </div>
      )}
    </div>
  );
}
