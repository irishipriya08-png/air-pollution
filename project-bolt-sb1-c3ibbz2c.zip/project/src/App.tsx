import { useState, useCallback } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { DashboardView } from '@/views/DashboardView';
import { MapView } from '@/views/MapView';
import { AnalyticsView } from '@/views/AnalyticsView';
import { AlertsView } from '@/views/AlertsView';
import { XAIView } from '@/views/XAIView';
import { SubscriptionsView } from '@/views/SubscriptionsView';
import { useAlerts, useMetrics } from '@/hooks/useData';
import type { ViewKey } from '@/types';

const VIEW_META: Record<ViewKey, { title: string; subtitle: string }> = {
  dashboard: { title: 'Command Center', subtitle: 'Real-time multi-hazard nowcasting overview' },
  map: { title: 'Risk Maps', subtitle: 'Hyper-local probability maps on spatiotemporal grid' },
  analytics: { title: 'Analytics', subtitle: 'Atmospheric variable trends and model performance' },
  alerts: { title: 'Alert Feed', subtitle: 'Categorized severe weather alerts for first responders' },
  xai: { title: 'Explainable AI', subtitle: 'Transparent meteorological trigger attribution' },
  subscriptions: { title: 'Subscribers', subtitle: 'Manage automated alert delivery to communities' },
};

function App() {
  const [activeView, setActiveView] = useState<ViewKey>('dashboard');
  const { alerts, load: reloadAlerts } = useAlerts();
  const { metrics, load: reloadMetrics } = useMetrics();

  const handleRefresh = useCallback(() => {
    reloadAlerts();
    reloadMetrics();
  }, [reloadAlerts, reloadMetrics]);

  const meta = VIEW_META[activeView];

  return (
    <div className="flex min-h-screen bg-ink-950 text-slate-200">
      <Sidebar activeView={activeView} onNavigate={setActiveView} alertCount={alerts.length} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          title={meta.title}
          subtitle={meta.subtitle}
          inferenceLatency={metrics?.inference_latency_ms ?? 340}
          accuracy={metrics?.accuracy_pct ?? 91.2}
          onRefresh={handleRefresh}
        />
        <main className="flex-1 overflow-y-auto animate-fade-in" key={activeView}>
          {activeView === 'dashboard' && <DashboardView />}
          {activeView === 'map' && <MapView />}
          {activeView === 'analytics' && <AnalyticsView />}
          {activeView === 'alerts' && <AlertsView />}
          {activeView === 'xai' && <XAIView />}
          {activeView === 'subscriptions' && <SubscriptionsView />}
        </main>
      </div>
    </div>
  );
}

export default App;
