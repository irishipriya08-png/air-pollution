import type {
  EventType,
  GridCell,
  MeteorologicalTriggers,
  Severity,
  VariableReading,
  WeatherAlert,
} from '@/types';

// India geographic bounds for grid generation
const INDIA_BOUNDS = {
  minLat: 6,
  maxLat: 37,
  minLng: 68,
  maxLng: 97,
};

const GRID_COLS = 40;
const GRID_ROWS = 32;

// Hotspot seeds — areas with elevated baseline risk
const HOTSPOTS = [
  { lat: 30.4, lng: 79.3, intensity: 0.92, radius: 4, type: 'cloudburst' as EventType },
  { lat: 31.9, lng: 77.1, intensity: 0.85, radius: 3.5, type: 'flash_flood' as EventType },
  { lat: 26.9, lng: 75.8, intensity: 0.78, radius: 4.5, type: 'thunderstorm' as EventType },
  { lat: 19.1, lng: 72.9, intensity: 0.72, radius: 3.8, type: 'cloudburst' as EventType },
  { lat: 25.6, lng: 85.1, intensity: 0.58, radius: 5, type: 'thunderstorm' as EventType },
  { lat: 13.0, lng: 77.5, intensity: 0.52, radius: 5.5, type: 'thunderstorm' as EventType },
  { lat: 23.0, lng: 91.0, intensity: 0.46, radius: 6, type: 'flash_flood' as EventType },
  { lat: 34.0, lng: 74.8, intensity: 0.62, radius: 3.5, type: 'cloudburst' as EventType },
];

let _randomSeed = 42;
function seedRandom(): number {
  _randomSeed = (_randomSeed * 1103515245 + 12345) & 0x7fffffff;
  return _randomSeed / 0x7fffffff;
}

export function generateRiskGrid(hourOffset = 0): GridCell[] {
  const cells: GridCell[] = [];
  const latStep = (INDIA_BOUNDS.maxLat - INDIA_BOUNDS.minLat) / GRID_ROWS;
  const lngStep = (INDIA_BOUNDS.maxLng - INDIA_BOUNDS.minLng) / GRID_COLS;

  for (let row = 0; row < GRID_ROWS; row++) {
    for (let col = 0; col < GRID_COLS; col++) {
      const lat = INDIA_BOUNDS.minLat + row * latStep + latStep / 2;
      const lng = INDIA_BOUNDS.minLng + col * lngStep + lngStep / 2;

      let risk = 0.05 + seedRandom() * 0.08;

      for (const hotspot of HOTSPOTS) {
        const dist = Math.sqrt(
          Math.pow(lat - hotspot.lat, 2) + Math.pow(lng - hotspot.lng, 2),
        );
        if (dist < hotspot.radius) {
          const influence = (1 - dist / hotspot.radius) * hotspot.intensity;
          // Shift risk slightly per hour for temporal variation
          const temporalShift = Math.sin((hourOffset + col) * 0.3) * 0.05;
          risk = Math.max(risk, influence + temporalShift);
        }
      }

      risk = Math.max(0, Math.min(1, risk));

      const iwv = 15 + risk * 35 + seedRandom() * 4;
      const cape = 200 + risk * 3500 + seedRandom() * 200;
      const ctt = 5 - risk * 30 - seedRandom() * 5;

      cells.push({
        lat,
        lng,
        risk,
        iwv,
        cape,
        ctt,
      });
    }
  }

  return cells;
}

export function getHotspots() {
  return HOTSPOTS;
}

export function generateVariableHistory(hours = 24): VariableReading[] {
  const readings: VariableReading[] = [];
  const now = Date.now();

  for (let i = hours - 1; i >= 0; i--) {
    const t = i / hours;
    const wave = Math.sin((hours - i) * 0.4);
    const noise = (seedRandom() - 0.5) * 0.15;

    readings.push({
      timestamp: new Date(now - i * 60 * 60 * 1000).toISOString(),
      iwv: 28 + wave * 12 + noise * 5,
      cape: 1800 + wave * 1400 + noise * 300,
      cin: -40 + wave * 30 + noise * 10,
      ctt: -10 - wave * 15 + noise * 3,
      convergence: 0.55 + wave * 0.25 + noise * 0.08,
      shear: 15 + wave * 8 + noise * 2,
      precipitation: 5 + Math.max(0, wave) * 45 + noise * 5,
    });
  }

  return readings;
}

export function generateForecastSeries(
  hours = 6,
): { hour: number; thunderstorm: number; cloudburst: number; flash_flood: number }[] {
  const series: { hour: number; thunderstorm: number; cloudburst: number; flash_flood: number }[] = [];

  for (let h = 0; h <= hours; h++) {
    const wave = Math.sin(h * 0.5);
    const decay = 1 - h * 0.06;
    series.push({
      hour: h,
      thunderstorm: Math.max(0, Math.min(1, (0.65 + wave * 0.2) * decay)),
      cloudburst: Math.max(0, Math.min(1, (0.72 + wave * 0.18) * decay)),
      flash_flood: Math.max(0, Math.min(1, (0.58 + wave * 0.15) * decay)),
    });
  }

  return series;
}

export function classifySeverity(probability: number): Severity {
  if (probability >= 0.8) return 'critical';
  if (probability >= 0.6) return 'warning';
  return 'watch';
}

export function generateTriggers(
  type: EventType,
  baseRisk: number,
): MeteorologicalTriggers {
  const iwv = 20 + baseRisk * 30 + seedRandom() * 4;
  const cape = 500 + baseRisk * 3000 + seedRandom() * 200;
  const cin = -100 + baseRisk * 80 + seedRandom() * 5;
  const cttDrop = -(2 + baseRisk * 7 + seedRandom() * 1.5);
  const convergence = 0.3 + baseRisk * 0.6 + seedRandom() * 0.05;
  const shear = 8 + baseRisk * 18 + seedRandom() * 2;

  const triggers: MeteorologicalTriggers = {
    iwv: parseFloat(iwv.toFixed(1)),
    cape: Math.round(cape),
    cin: Math.round(cin),
    ctt_drop: parseFloat(cttDrop.toFixed(1)),
    convergence: parseFloat(convergence.toFixed(2)),
    shear: Math.round(shear),
  };

  if (type === 'flash_flood') {
    triggers.slope = Math.round(15 + baseRisk * 30 + seedRandom() * 5);
    triggers.elevation = Math.round(800 + baseRisk * 2000 + seedRandom() * 200);
  }

  return triggers;
}

export interface XAIContribution {
  variable: string;
  label: string;
  contribution: number;
  value: string;
  threshold: string;
  status: 'breached' | 'approaching' | 'normal';
}

export function generateXAIContributions(
  type: EventType,
  triggers: MeteorologicalTriggers,
): XAIContribution[] {
  const contributions: XAIContribution[] = [
    {
      variable: 'iwv',
      label: 'Integrated Water Vapor',
      contribution: type === 'cloudburst' ? 0.32 : 0.22,
      value: `${triggers.iwv} kg/m²`,
      threshold: '> 35 kg/m²',
      status: triggers.iwv > 40 ? 'breached' : triggers.iwv > 35 ? 'approaching' : 'normal',
    },
    {
      variable: 'cape',
      label: 'CAPE (Instability)',
      contribution: type === 'thunderstorm' ? 0.28 : 0.18,
      value: `${triggers.cape} J/kg`,
      threshold: '> 2500 J/kg',
      status: triggers.cape > 3000 ? 'breached' : triggers.cape > 2500 ? 'approaching' : 'normal',
    },
    {
      variable: 'cin',
      label: 'CIN (Convective Inhibition)',
      contribution: 0.12,
      value: `${triggers.cin} J/kg`,
      threshold: '< -25 J/kg',
      status: triggers.cin > -25 ? 'normal' : triggers.cin > -50 ? 'approaching' : 'breached',
    },
    {
      variable: 'ctt_drop',
      label: 'Cloud Top Temp Drop Rate',
      contribution: 0.15,
      value: `${triggers.ctt_drop} K/min`,
      threshold: '< -5 K/min',
      status: triggers.ctt_drop < -7 ? 'breached' : triggers.ctt_drop < -5 ? 'approaching' : 'normal',
    },
    {
      variable: 'convergence',
      label: 'Low-Level Convergence',
      contribution: 0.13,
      value: `${triggers.convergence}`,
      threshold: '> 0.75',
      status: triggers.convergence > 0.85 ? 'breached' : triggers.convergence > 0.75 ? 'approaching' : 'normal',
    },
    {
      variable: 'shear',
      label: 'Vertical Wind Shear',
      contribution: 0.1,
      value: `${triggers.shear} m/s`,
      threshold: '> 15 m/s',
      status: triggers.shear > 20 ? 'breached' : triggers.shear > 15 ? 'approaching' : 'normal',
    },
  ];

  if (type === 'flash_flood' && triggers.slope !== undefined) {
    contributions.push({
      variable: 'slope',
      label: 'Terrain Slope (DEM)',
      contribution: 0.25,
      value: `${triggers.slope}°`,
      threshold: '> 20°',
      status: triggers.slope > 30 ? 'breached' : triggers.slope > 20 ? 'approaching' : 'normal',
    });
  }

  return contributions.sort((a, b) => b.contribution - a.contribution);
}

export const EVENT_META: Record<EventType, { label: string; shortLabel: string; color: string }> = {
  thunderstorm: { label: 'Severe Thunderstorm', shortLabel: 'Thunderstorm', color: '#f59e0b' },
  cloudburst: { label: 'Cloudburst', shortLabel: 'Cloudburst', color: '#ef4444' },
  flash_flood: { label: 'Flash Flood', shortLabel: 'Flash Flood', color: '#3b82f6' },
};

export const SEVERITY_META: Record<Severity, { label: string; color: string; bg: string }> = {
  watch: { label: 'Watch', color: '#eab308', bg: 'rgba(234, 179, 8, 0.12)' },
  warning: { label: 'Warning', color: '#f97316', bg: 'rgba(249, 115, 22, 0.12)' },
  critical: { label: 'Critical', color: '#ef4444', bg: 'rgba(239, 68, 68, 0.12)' },
};

export function riskToColor(risk: number): string {
  if (risk < 0.15) return 'rgba(20, 40, 60, 0.15)';
  if (risk < 0.3) return 'rgba(34, 197, 94, 0.35)';
  if (risk < 0.45) return 'rgba(234, 179, 8, 0.45)';
  if (risk < 0.6) return 'rgba(249, 115, 22, 0.55)';
  if (risk < 0.75) return 'rgba(239, 68, 68, 0.65)';
  return 'rgba(220, 38, 38, 0.8)';
}

export type { WeatherAlert };
