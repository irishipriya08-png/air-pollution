/*
# Weather Nowcasting Alert Schema

1. New Tables
- `weather_alerts`: Stores generated severe weather alerts (thunderstorms, cloudbursts, flash floods)
  - id, event_type, severity, location_name, lat, lng, probability, lead_time_hours,
    description, meteorological_triggers (jsonb), status, created_at, expires_at
- `alert_subscriptions`: Stores community/first-responder subscription registrations
  - id, contact_name, phone, email, district, state, alert_types (text[]), created_at
- `system_metrics`: Stores engine health and prediction metrics snapshots
  - id, model_version, inference_latency_ms, grid_cells_analyzed, active_alerts,
    coverage_area_km2, accuracy_pct, timestamp

2. Security
- Enable RLS on all tables.
- Allow anon + authenticated CRUD (single-tenant public demo, no sign-in).
*/

CREATE TABLE IF NOT EXISTS weather_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL CHECK (event_type IN ('thunderstorm', 'cloudburst', 'flash_flood')),
  severity text NOT NULL CHECK (severity IN ('watch', 'warning', 'critical')),
  location_name text NOT NULL,
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  probability double precision NOT NULL CHECK (probability >= 0 AND probability <= 1),
  lead_time_hours integer NOT NULL,
  description text,
  meteorological_triggers jsonb DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'acknowledged')),
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz
);

ALTER TABLE weather_alerts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_alerts" ON weather_alerts;
CREATE POLICY "anon_select_alerts" ON weather_alerts FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_alerts" ON weather_alerts;
CREATE POLICY "anon_insert_alerts" ON weather_alerts FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_alerts" ON weather_alerts;
CREATE POLICY "anon_update_alerts" ON weather_alerts FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_alerts" ON weather_alerts;
CREATE POLICY "anon_delete_alerts" ON weather_alerts FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_weather_alerts_status ON weather_alerts(status);
CREATE INDEX IF NOT EXISTS idx_weather_alerts_created ON weather_alerts(created_at DESC);

CREATE TABLE IF NOT EXISTS alert_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_name text NOT NULL,
  phone text,
  email text,
  district text NOT NULL,
  state text NOT NULL,
  alert_types text[] DEFAULT ARRAY['thunderstorm', 'cloudburst', 'flash_flood'],
  created_at timestamptz DEFAULT now()
);

ALTER TABLE alert_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_subscriptions" ON alert_subscriptions;
CREATE POLICY "anon_select_subscriptions" ON alert_subscriptions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_subscriptions" ON alert_subscriptions;
CREATE POLICY "anon_insert_subscriptions" ON alert_subscriptions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_subscriptions" ON alert_subscriptions;
CREATE POLICY "anon_update_subscriptions" ON alert_subscriptions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_subscriptions" ON alert_subscriptions;
CREATE POLICY "anon_delete_subscriptions" ON alert_subscriptions FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS system_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_version text NOT NULL DEFAULT 'NowCastNet-v2.1',
  inference_latency_ms integer NOT NULL,
  grid_cells_analyzed integer NOT NULL,
  active_alerts integer NOT NULL,
  coverage_area_km2 double precision NOT NULL,
  accuracy_pct double precision NOT NULL,
  timestamp timestamptz DEFAULT now()
);

ALTER TABLE system_metrics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_metrics" ON system_metrics;
CREATE POLICY "anon_select_metrics" ON system_metrics FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_metrics" ON system_metrics;
CREATE POLICY "anon_insert_metrics" ON system_metrics FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_metrics" ON system_metrics;
CREATE POLICY "anon_delete_metrics" ON system_metrics FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics(timestamp DESC);
